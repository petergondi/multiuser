<!-- Main Footer -->
<footer class="main-footer text-right">
    <strong>Copyright &copy; {{ date('Y') }} <a href="#">Movetech</a>.</strong> 
</footer>