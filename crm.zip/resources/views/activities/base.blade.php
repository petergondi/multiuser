@extends('layouts.master')
@section('content')
    <!-- Content Header (Page header) -->
    <section class=" content-header text-left">
      <h4><i class="fa fa-wrench bg-secondary"></i>
        Activity Management
      </h4>
    </section>
    @yield('action-content')
    <!-- /.content -->
@endsection