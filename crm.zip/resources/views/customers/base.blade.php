@extends('layouts.master')
@section('content')
    <!-- Content Header (Page header) -->
    <section class="content-header text-center">
      <h1>
       Customers
      </h1>
    </section>
    @yield('action-content')
    <!-- /.content -->
@endsection