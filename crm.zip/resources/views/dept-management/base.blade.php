@extends('layouts.master')
@section('content')
    <!-- Content Header (Page header) -->
    <section class=" content-header text-left">
      <h4><i class="fa fa-building bg-secondary"></i>
        Department Management
      </h4>
    </section>
    @yield('action-content')
    <!-- /.content -->
@endsection