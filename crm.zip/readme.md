
front-office system consisting of petty cashbook, employee management and task tracking system
