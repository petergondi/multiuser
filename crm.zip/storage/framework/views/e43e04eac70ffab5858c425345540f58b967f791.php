<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content">
    <section class="content">
       
    <div class="container-fluid alert alert-success" role="alert">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                <section class="content-header text-left">
    <p > <i class="fa fa-arrow-left"></i>This page shows you an overview of your created expense accounts. The top bar shows the amount that is available to be budgeted. 
    .<a href=""><i class="fa fa-info-circle" style="font-size:13px"></i></a><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
    </section>
                    <div class="col-sm-8"><p><strong>User Details</strong></p></div>
                    <div class="col-sm-4">
                            <a href="/admin/user/create">
                        <button type="button" class="btn btn-success add-new"><i class="fa fa-plus"></i> Add New User</button>
                            </a>
                           
                    </div>
                </div>
                 <br/>
            </div>
            <table  class="table table-bordered container-fluid">
                <thead >
                    <tr class="bg-primary" >
                        <th >No</th>
                        <th >Date</th>
                        <th >Email</th>
                        <th>FirstName</th>
                        <th>MIddleName</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >       
                    <td><b><?php echo e($user->id); ?></b></td>
                    <td><b><?php echo e($user->created_at->format('d/m/Y')); ?></b></td>
                    <td><b><?php echo e($user->email); ?></b></td>
                    <td><b><?php echo e($user->firstname); ?></b></td>
                    <td><b><?php echo e($user->middlename); ?></b></td>
                    <td><b><?php echo e($user->role); ?></b></td>
                        <td>
                         <a style="float:left;" href="/admin/user/edit/<?php echo e($user->id); ?>" data-placement="top" data-toggle="tooltip" title="view"><button class="btn btn-success btn-xs " data-title="view" data-toggle="modal" data-target="#view" ><span class="fa fa-eye"></span></button>&nbsp;&nbsp; </a>
                                <a style="float:left;" href="/admin/user/edit/<?php echo e($user->id); ?>" data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs " data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button>&nbsp;&nbsp; </a>
                                <?php echo Form::open(['action' => ['UserController@destroy',$user->id],'method'=>'DELETE']); ?>

                                <p style="float:left;" data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p>
                                <?php echo Form::close(); ?>

                          </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>
            <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
                <?php echo e($users->links()); ?>

              </div>
              <a href="javascript:history.back()" class="btn btn-default">Back</a>
        </div>
    </div>     
</body>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>