<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid alert alert-success" role="alert"">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default ">
            <div class="panel-body"><a href="info"><i class="fa fa-info-circle " style="font-size:15px"></i></a> On this page you can log in as more than one user level and perform the dedicated roles assigned to each user level. 
 The sidebar will show you all the available operations you can perform once logged in as one of the user levels. 
   .</div>
                <div class="panel-heading text-center">Add new Department</div>
                <div class="panel-body">
                       
                        <?php echo Form::open(['action' => 'DepartmentController@store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                        <?php echo e(csrf_field()); ?>

                        <div class="form-group<?php echo e($errors->has('number') ? ' has-error' : ''); ?>">
                            <label for="number" class="col-md-4 control-label">Department number</label>

                            <div class="col-md-6">
                                <input id="number" type="text" class="form-control" name="number" value="<?php echo e(old('number')); ?>" required autofocus>

                                <?php if($errors->has('number')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('number')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Department Name</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required>

                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="address" class="col-md-4 control-label">Department Email</label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('customer_name') ? ' has-error' : ''); ?>">
                                        <label for="customer_name" class="col-md-4 control-label">Incharge</label>
                                        <div class="col-md-6">
                                            <select class="form-control" name="customer_name" id="firstname">
                                                    <option value="" selected>Select Incharge</option>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->firstname); ?>"><?php echo e($user->firstname); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </select>
                                            <?php if($errors->has('firstname')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('firstname')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                        
                        </div>
                        </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Create
                                </button>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dept-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>