<form action="/sender" action=post>
<input type="text" name="content">
<input type="submit">
<?php echo e(csrf_field()); ?>