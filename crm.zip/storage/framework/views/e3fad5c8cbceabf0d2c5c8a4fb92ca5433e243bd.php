<?php $__env->startSection('action-content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="content">
       <!-- Modal -->
 <section class="content-header text-center">
      <h5>
        No Task Assigned Yet
      </h5>
    </section>
   
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('task-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>