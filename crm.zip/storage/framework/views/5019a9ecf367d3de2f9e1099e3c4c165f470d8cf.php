<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div style="width:auto;border-color:black;" class="container alert alert-success" role="alert">
	<div class="row">
        <p>You are replying to The following assigned task</p>
        <?php $__currentLoopData = $taskassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskassign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <div class="invisible"><?php echo e($taskid=$taskassign->id); ?></div>
        <h4 style="text-center">
        <?php if($checkproject==true): ?>Project:
        <?php else: ?>
        Task:
        <?php endif; ?>
        <?php echo e($taskassign->task_name); ?></h4> 
        <p style="float-center">Description:<?php echo e($taskassign->description); ?></p> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Comments <span class="badge"><?php echo e($comments->count()); ?></span><span class="caret"></span>
                   </a>
                   <br/>
                  
                   <div  class="collapse" id="collapseExample">
                       <br/>
                       <?php if($comments->count()==0): ?>
                      <p>No comments posted</p>
                      <?php else: ?>
                   <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($comment->user_id==0): ?>
                     <div  style="width:auto;" class="container1">
                       <span  class="time-left"><strong>Admin</strong></span>
                       <img src="https://cdn4.iconfinder.com/data/icons/people-std-pack/512/boss-512.png" alt="Avatar" style="width:100%;">
                     <p><?php echo e($comment->reply); ?></p>
                       <span class="time-left"><?php echo e($comment->created_at); ?></span>
                     </div>
                     <hr>
                     <?php else: ?>
                     <div style="width:auto;" class="container darker">
                     <span  class="time-left"><strong><?php echo e($comment->user->firstname); ?></strong></span>
                       <img src=" https://cdn3.vectorstock.com/i/1000x1000/30/97/flat-business-man-user-profile-avatar-icon-vector-4333097.jpg" alt="Avatar" class="right" style="width:100%;">
                       <p><?php echo e($comment->reply); ?></p>
                       <span class="time-left"><?php echo e($comment->created_at); ?></span>
                     </div>
                     <hr>
                     <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                   </div>
                   <br/>
                <?php echo Form::open(['action' => ['ReplyController@replyTask',$taskid,$userid],'method'=>'POST','enctype'=>'multipart/form-data']); ?>

                <?php echo e(csrf_field()); ?>

<div class="form-horizontal">
    <fieldset>
<!-- Form Name -->
<legend>Reply to the Assigned task</legend>
<!-- Textarea -->
<div class="form-group">
  <div class="col-md-12">                   
    <textarea class="form-control" id="textarea" name="reply" cols="30" rows="5" placeholder="reply to the task"></textarea>
</div>
</div>

<!-- Button -->
<div class="form-group">
  <div class="col-md-4">
    <button id="singlebutton" name="singlebutton" class="btn btn-success pull-right">reply</button>
  </div>
</div>

</fieldset>
</div>
<?php echo Form::close(); ?>


	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('task-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>