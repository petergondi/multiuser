<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
	<div class="row">
        <h4>You are replying to The following assigned task</h4>
        <?php $__currentLoopData = $taskassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskassign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <div class="invisible"><?php echo e($taskid=$taskassign->id); ?></div>
        <h3 style="text-center">Task Name:<?php echo e($taskassign->task_name); ?></h3> 
        <h4 style="float-center">Task Description:<?php echo e($taskassign->description); ?></h4> 
        <?php if(auth()->guard()->check()): ?>
        <message :messages="messages"></message>
        <sent-message v-on:messagesent="addMessage" :user="<?php echo e(Auth::user()); ?>"></sent-message>
        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                    Comments <span class="badge"><?php echo e($comments->count()); ?></span><span class="caret"></span>
                   </a>
                   <br/>
                   <div class="collapse" id="collapseExample">
                       <br/>
                       <?php if($comments->count()==0): ?>
                      <p>No comments posted on this task</p>
                      <?php else: ?>
                   
                   <?php endif; ?>
                   </div>
                   <br/>
              


	</div>
</div>
<script>


require('./bootstrap');

window.Vue = require('vue');


Vue.component('message', require('./components/Message.vue'));
Vue.component('sent-message', require('./components/Sent.vue'));

const app = new Vue({
    el: '#app',
    data: {
    	messages: []
        },
    mounted(){
    	this.fetchMessages();
        Echo.private('my-channel')
            .listen('FormSubmitted', (e) => {
                this.messages.push({
                    reply: e.reply.reply,
                    user: e.user,
                    task:e.task
                })
      })
    },
    methods: {
    	addMessage(message) {
            this.messages.push(message)
            axios.post('/messages', message).then(response => {
                //console.log(response)
            })
        },
        fetchMessages() {
            axios.get('/messages').then(response => {
                this.messages = response.data
            })
        }
    }
    
});





</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('task-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>