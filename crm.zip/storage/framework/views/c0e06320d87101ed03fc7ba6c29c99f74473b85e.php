<!DOCTYPE html>

<html>
<head>
  <title>Pusher Test</title>
  <script src="<?php echo e(('https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('https://js.pusher.com/4.3/pusher.min.js')); ?>"></script>
  <link rel="<?php echo e(asset('css/app.css')); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<body>
    <div id="app">
  <h1>Pusher Test</h1>
    </div>
  <p>
    Try publishing an event to channel <code>my-channel</code>
    with event name <code>my-event</code>.
  </p>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>