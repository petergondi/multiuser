<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class=" content-header text-left">
      <h4><i class="fa fa-phone bg-secondary"></i>
        Call Management
      </h4>
    </section>
    <?php echo $__env->yieldContent('action-content'); ?>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>