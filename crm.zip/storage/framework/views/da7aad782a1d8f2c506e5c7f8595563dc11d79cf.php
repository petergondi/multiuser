<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
.toggle-header{
    padding:10px 0;
    margin:10px 0;
    background-color:black;
    color:white;
}
.txt-green{
    color:green;
}
.txt-red{
    color:red;
}
.radio,
.checkbox {
  margin-top: 0px;
  margin-bottom: 0px;
  }
</style>
<section class="container-fluid alert alert-success" role="alert">
<div class="container-fluid">
 <h1>Activities</h1>
	<div class="row">
	<div class="panel panel-default clearfix">
                            <div class="panel-heading">
                                <h2 class="panel-title">User Activities</h2>
                                <p class="small">
                                    This Section contain your Daily Routine, you can create activities and mark them on completetion                             
                                </p>
                            </div>
                            <div class="col-xs-12 toggle-header">
                                <div class="col-xs-6">
                                    <button type="button" class="btn btn-primary btn-sm hidden-xs" data-toggle="collapse" data-target="#feature-1">
                                        <i class="glyphicon glyphicon-resize-vertical"></i>Toggle Activities
                                    </button>
                                    <button type="button" class="btn btn-primary btn-xs visible-xs" data-toggle="collapse" data-target="#feature-1">
                                        <i class="glyphicon glyphicon-resize-vertical"></i>Toggle Set
                                    </button>
                                </div>
                                <div class="col-xs-2 text-center">
                                    <span class="hidden-xs">Comment</span>
                                    <span class="visible-xs">C</span>
                                </div>
                                <div class="col-xs-2 text-center">
                                     <span class="hidden-xs">In Progress</span>
                                    <span class="visible-xs">M</span>
                                </div>
                                <div class="col-xs-2 text-center">
                                     <span class="hidden-xs">Complete</span>
                                    <span class="visible-xs">L</span>
                                    <span class="hidden-xs">Save</span>
                                    <span class="visible-xs">S</span>
                                </div>
                            </div>
                            
                                <div id="feature-1" class="collapse in">
                                <?php $__currentLoopData = $user_activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-xs-6">
                                                   <?php echo e($user_activity->activity); ?>                                            
                                                </div>
                                                <div class="col-xs-2 text-center">
                                                   <textarea  name="is_company" placeholder="max 100 characters"></textarea>
                                                    <span class="checkround"></span>
                                                </div>
                                                <div class="col-xs-2 text-center">
                                               <input type="radio" name="is_company">
                                                    <span class="checkround"></span>
                                                </div>
                                                <div class="col-xs-2 text-center">
                                                  <input type="radio" name="is_company">
                                                    <span class="checkround"></span>
                                                    <button type="button" class="btn btn-sm btn-primary pull-right"><i class="fa fa-save"></i></button>
                                        </div> 
                                        
                                        </div>
                                        </div> 
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            </div>
	                </div>
                </div>
<button type="button" class="btn btn-sm btn-success pull-right"><i class="fa fa-file-archive-o"></i>Send Monthly Report</button>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('activities.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>