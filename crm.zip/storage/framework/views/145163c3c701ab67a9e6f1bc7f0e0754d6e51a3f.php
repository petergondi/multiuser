<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content">
    <div  class="container-fluid alert alert-success" role="alert">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><p>Calls Details<a href=""><i class="fa fa-info-circle pull-right" style="font-size:13px"></i></a> </p></div>
                    
                </div>
            </div>
            <table class="table table-bordered ">
                <thead>
                    <tr class="bg-primary">
                        <th>Caller Name</th>
                        <th>Caller Email</th>
                        <th>Caller Tel.</th>
                        <th>Caller Location</th>
                        <th>Call Reason</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $calls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $call): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>       
                    <td><b><?php echo e($call->customer->customer_name); ?></b></td>
                    <td><b><?php echo e($call->email); ?></b></td>
                    <td><b><?php echo e($call->contact); ?></b></td>
                    <td><b><?php echo e($call->location); ?></b></td>
                     <td><b><?php echo e($call->reason); ?></b></td>
                     <td><b><?php echo e($call->created_at); ?></b></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
                
              </div>
        </div>
    </div> 
     
</body>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('call-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>