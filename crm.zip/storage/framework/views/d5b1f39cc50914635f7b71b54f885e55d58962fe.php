<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div id="signupbox" style=" margin-top:30px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
    <div class="panel panel-info">
        <div class="panel-heading">
            <div class="panel-title fa fa-envelope">SMS Settings</div>
        </div> 
        <?php echo Form::open(['action' => 'SmsController@smsform','method'=>'POST','enctype'=>'multipart/form-data']); ?>

        <?php echo e(csrf_field()); ?> 
        <div class="panel-body" >
            <div class="form-group<?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
                <label for="username" style="color:black;" class="col-md-4 control-label">Username</label>

                <div class="col-md-6">
                    <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                    <?php if($errors->has('username')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('username')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="form-group<?php echo e($errors->has('sender_id') ? ' has-error' : ''); ?>">
                <label for="sender_id"  style="color:black;" class="col-md-4 control-label">Sender-ID</label>

                <div class="col-md-6">
                    <input id="sender_id" type="text" class="form-control" name="sender_id" value="<?php echo e(old('sender_id')); ?>" required>

                    <?php if($errors->has('sender_id')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('sender_id')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <label for="api"  style="color:black;" class="col-md-4 control-label">API Key</label>

                <div class="col-md-6">
                    <input id="api" type="text" class="form-control" name="api" value="<?php echo e(old('api')); ?>" required>

                    <?php if($errors->has('api')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('api')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
</div> 
</div>






</div>            

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('setting.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>