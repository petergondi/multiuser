<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content">  
<div class="container-fluid alert alert-success" role="alert">
<p class="card-header text-center font-weight-bold text-uppercase py-4">Assigned Tasks &nbsp;<span class="badge bg-info"><?php echo e($totaltask=App\Task::All()->count()); ?></span></p>
<p >Tasks Not replied To:  &nbsp;<span class="glyphicon glyphicon-envelope"><span class="badge bg-warning"><?php echo e($unreplied=App\Task::where('status','no')->count()); ?></span></span></p> 
            <div class="row">
                <div class="col-sm-4 pull-right">
                        <a href="/admin/tasks/assign">
                    <button type="button" class="btn btn-success add-new "><i class="fa fa-plus"></i> Assign New Task</button>
                        </a>
                </div>
            </div>
            <br/>
        <div class="card-body">
          <div id="table">
            <table class="table table-bordered table-striped table-hover table-responsive">
              <tr>
                <th class=" bg-primary">Task</th>
                <th class=" bg-primary">Description</th>
                <th class=" bg-primary">Customer</th>
                <th class=" bg-primary">Date</th>
                <th class=" bg-primary">Location</th>
                <th class=" bg-primary">Contact</th>
                <th class=" bg-primary">Customer Email</th>
                <th class=" bg-primary">Assignee</th>
                <th class="bg-primary">Status</th>
                <th class=" bg-primary">Project</th>
                <th class=" bg-primary">Comment</th>
                <th class=" bg-primary">View</th>
                <th class=" bg-primary">Edit</th>
                <th class=" bg-primary">Delete</th>
              </tr>
              <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="pt-2-half" ><?php echo e($task->task_name); ?></td>
                <td class="pt-2-half" ><?php echo e($task->description); ?></td>
                <td class="pt-2-half" ><?php echo e($task->customer->customer_name); ?></td>
                <td class="pt-2-half" ><?php echo e($task->created_at->format('d/m/Y')); ?></td>
                <td class="pt-2-half" ><?php echo e($task->location); ?></td>
                <td class="pt-2-half" ><?php echo e($task->contact); ?></td>
                <td class="pt-2-half" ><?php echo e($task->email); ?></td>
                <?php if($task->user->firstname==null): ?>
                  <td class="pt-2-half" ></td>
                <?php else: ?>
                <td class="pt-2-half" ><?php echo e($task->user->firstname); ?></td>
                 <?php endif; ?>
                    <td class="pt-2-half" >
                    <?php if($task->status=="yes"): ?>
                  <span class="label label-primary">Replied</span>
                  <?php else: ?>
                    <span class="label label-warning">Not Replied</span>
                    <?php endif; ?>
                    </td>
                    <?php if(App\Project::where('taskid',$task->id)->first()): ?>
                      <td class="pt-2-half" ><span class="label label-info">Yes</span></td>
                         <td  class="pt-2-half">
                    <?php else: ?>
                      <td class="pt-2-half" ><span class="label label-dark">No</span></td>
                         <td  class="pt-2-half">
                    <?php endif; ?>
                    <a href="/admin/tasks/comment/<?php echo e($taskasignned=$task->id); ?>" style="float:left;" data-placement="top" data-toggle="tooltip" title="reply"><button class="btn btn-success btn-xs pull-right " data-title="reply" data-toggle="modal" data-target="#reply" ><span class="fa fa-reply"></span></button></a>
                    </td>
                          <td  class="pt-2-half">
                    <a href="/admin/tasks/edit/<?php echo e($task->id); ?>" style="float:left;" data-placement="top" data-toggle="tooltip" title="view"><button class="btn btn-info btn-xs pull-right " data-title="view" data-toggle="modal" data-target="#view" ><span class="fa fa-eye"></span></button></a>
                    </td>
                <td class="pt-2-half">
                <a href="/admin/tasks/edit/<?php echo e($task->id); ?>" style="float:left;" data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs pull-right " data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button></a>
                  <?php echo Form::open(['action' => ['TaskController@destroy',$task->id],'method'=>'DELETE']); ?>

                  </td>
                <td class="pt-2-half"><p style="float:left;" data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs pull-right" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p></td>
                <?php echo Form::close(); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </table>
            <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
              <?php echo e($tasks->links()); ?>

            </div>
          </div>
        </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('task-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>