<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content">
  
    <div  class="container-fluid alert alert-success" role="alert">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><p>Customers Details<a href=""><i class="fa fa-info-circle pull-right" style="font-size:13px"></i></a> </p></div>
                    
                </div>
            </div>
            <?php if($customers->count()==0): ?>
            <p>No Customer Data </p>
            <?php else: ?>
            <table class="table table-bordered ">
                <thead>
                    <tr class="bg-primary">
                        <th>Customer Name</th>
                        <th>Customer Email</th>
                        <th>Customer Tel.</th>
                        <th>Customer Location</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>       
                    <td><b><?php echo e($customer->customer_name); ?></td>
                    <td><b><?php echo e($customer->email); ?></b></td>
                    <td><b><?php echo e($customer->contact); ?></b></td>
                    <td><b><?php echo e($customer->location); ?></b></td>
                        <td>
                            <p style="float:left;" data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>
            <?php endif; ?>
            <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
                <?php echo e($customers->links()); ?>

              </div>
        </div>
    </div> 
     
</body>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customers.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>