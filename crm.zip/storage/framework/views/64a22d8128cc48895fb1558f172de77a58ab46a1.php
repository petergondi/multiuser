<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="content">
       
        <div class="container-fluid alert alert-success" role="alert">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-8"><p>Department <b>Details</b></p></div>
                    <div class="col-sm-4">
                            <a href="/admin/dept/create">
                        <button type="button" class="btn btn-info add-new"><i class="fa fa-plus"></i> Add New Department</button>
                            </a>
                    </div>
                </div>
            </div>
            <table class="table table-bordered ">
                <thead>
                    <tr class="bg-primary">
                        <th>Department Code</th>
                        <th>Name</th>
                        <th>Department</th>
                        <th>Incharge</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                        <?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>       
                    <td><b><?php echo e($dept->number); ?></td>
                    <td><b><?php echo e($dept->name); ?></b></td>
                    <td><b><?php echo e($dept->email); ?></b></td>
                    <td><b><?php echo e($dept->firstname); ?></b></td>
                        <td>
                            <a style="float:left;" href="/admin/dept/edit/<?php echo e($dept->id); ?>" data-placement="top" data-toggle="tooltip" title="Edit"><button class="btn btn-primary btn-xs " data-title="Edit" data-toggle="modal" data-target="#edit" ><span class="glyphicon glyphicon-pencil"></span></button>&nbsp;&nbsp;</a>
                            <?php echo Form::open(['action' => ['DepartmentController@destroy',$dept->id],'method'=>'DELETE']); ?>

                            <p style="float:left;" data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button></p>
                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </tbody>
            </table>
            <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
                <?php echo e($depts->links()); ?>

              </div>
        </div>
    </div> 
   
</body>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dept-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>