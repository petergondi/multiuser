<?php $__env->startSection('action-content'); ?>
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading ">Edit Task</div>
                <?php if(!isset($task->id)): ?>
                <?php echo Form::open(['action' => 'TaskController@storeTask','method'=>'POST','enctype'=>'multipart/form-data']); ?>

        <?php else: ?>
        <?php echo Form::open(['action' => ['TaskController@update',$task->id,$task->customer_name],'method'=>'POST','enctype'=>'multipart/form-data']); ?>

        <input type="hidden" name="_method" value="PUT">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <?php endif; ?>
       
                <div class="panel-body">
                        <div class="form-group<?php echo e($errors->has('task_name') ? ' has-error' : ''); ?>">
                            <label for="task_name" class="col-md-4 control-label">Task Name</label>

                            <div class="col-md-6">
                                <input id="task_name" type="text" class="form-control" name="task_name" value="<?php echo e($task->task_name); ?>" required autofocus>

                                <?php if($errors->has('task_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('task_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <label for="description" class="col-md-4 control-label">Task Description</label>

                            <div class="col-md-6">
                                <input id="description" type="text" class="form-control" name="description" value="<?php echo e($task->description); ?>" required>

                                <?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('customer_name') ? ' has-error' : ''); ?>">
                            <label for="customer_name" class="col-md-4 control-label">Customer Name</label>

                            <div class="col-md-6">
                                <input id="customer_name" type="text" class="form-control" name="customer_name" value="<?php echo e($task->customer_name); ?>" required>

                                <?php if($errors->has('customer_name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('customer_name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('location') ? ' has-error' : ''); ?>">
                            <label for="location" class="col-md-4 control-label">Location</label>

                            <div class="col-md-6">
                                <input id="location" type="text" class="form-control" name="location" value="<?php echo e($task->location); ?>" required>

                                <?php if($errors->has('Location')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('location')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                <label for="contact" class="col-md-4 control-label">Customer Contact</label>
    
                                <div class="col-md-6">
                                    <input id="contact" type="tel" class="form-control" name="contact" value="<?php echo e($task->contact); ?>" required>
    
                                    <?php if($errors->has('contact')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('contact')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label for="email" class="col-md-4 control-label">Customer email</label>
        
                                    <div class="col-md-6">
                                        <input id="email" type="text" class="form-control" name="email" value="<?php echo e($task->email); ?>" required>
        
                                        <?php if($errors->has('email')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group<?php echo e($errors->has('asignee_name') ? ' has-error' : ''); ?>">
                                        <label for="asignee_name" class="col-md-4 control-label">Assignee</label>
            
                                        <div class="col-md-6">
                                            <input id="asignee_name" type="text" class="form-control" name="asignee_name" value="<?php echo e($task->asignee_name); ?>" required>
            
                                            <?php if($errors->has('asignee_name')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('asignee_name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary pull-right">
                                    Update
                                </button>
                            </div>
                        </div>
                        
                        </div>
                        </div>
                        </div>
                        
                        <?php echo Form::close(); ?>

                        <a href="javascript:history.back()" class="btn btn-default">Back</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('task-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>