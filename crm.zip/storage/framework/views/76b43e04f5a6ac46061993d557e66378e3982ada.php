<!-- Main Footer -->
<footer class="main-footer text-right">
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#">Movetech</a>.</strong> 
</footer>