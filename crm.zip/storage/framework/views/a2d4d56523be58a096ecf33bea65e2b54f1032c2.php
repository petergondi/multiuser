<?php $__env->startSection('action-content'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 <style>
        .progress { position:relative; width:100%; border: 1px solid #7F98B2; padding: 1px; border-radius: 3px; }
        .bar { background-color: #B4F5B4; width:0%; height:25px; border-radius: 3px; }
        .percent { position:absolute; display:inline-block; top:3px; left:48%; color: #7F98B2;}
    </style>
<section class="container-fluid alert alert-success" role="alert">
<div class="card">
<p class="card-header text-center font-weight-bold text-uppercase py-3"><strong><?php echo e($check_tasks->reason); ?></strong><span class="badge"></span></p>
        <div class="card">
  <h5 class="card-header h4"><strong><?php echo e($check_tasks->task_name); ?></strong></h4>
  <div class="card-body">
    <h5 class="card-title"><strong>Task Details</strong></h5>
    
  <ul>
    <li>Category:<?php echo e($check_tasks->customer->customer_name); ?></li>
    <li>Task:<?php echo e($check_tasks->customer->customer_name); ?></li>
    <li>Email:<?php echo e($check_tasks->email); ?></li>
    <li>Location:<?php echo e($check_tasks->location); ?></li>
    <li>Contact:<?php echo e($check_tasks->contact); ?></li>
    <li>Status:<?php echo e($check_tasks->contact); ?></li>
    <li>Project:<?php echo e($check_tasks->contact); ?></li>
  </ul>
  <div class="card-header">
  <h5 class="card-title"><strong>Description</strong></h5>
  </div>
  <div class="card-body">
    <blockquote class="blockquote mb-0">
      <p><?php echo e($check_tasks->description); ?></p>
      <footer class="blockquote-footer">client/supplier <cite title="Source Title"> <?php echo e($check_tasks->customer->customer_name); ?></cite></footer>
    </blockquote>
  </div>
</div>
  </div>
</div>
 
            </div>
            <a href="javascript:history.back()" class="btn btn-default pull-right">Back</a>
        </div>
    </div>
  </div>
  
          </div>
        </div>
      </div>

      <?php $__env->stopSection(); ?>
<?php echo $__env->make('task-management.base', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>